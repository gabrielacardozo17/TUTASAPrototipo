namespace TUTASAPrototipo.Almacenes
{
    public enum TipoHDREnumeracion
    {
        // Valores originales
        Distribucion,
        Retiro,
        Transporte,
        // Nuevos valores usados por modelos (m�s espec�ficos)
        UltimaMilla,
        DespachoAgencia
    }
}