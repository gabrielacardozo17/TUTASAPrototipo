namespace TUTASAPrototipo.Almacenes
{
    public enum ExtrasEnum
    {
        ExtraRetiroDomicilio,
        ExtraEntregaDomicilio,
        ExtraEntregaAgencia
    }
}
