namespace TUTASAPrototipo.Almacenes
{
 // Enum de Bodega con letras A�D para alinear nombres con el c�digo
 public enum BodegaEnum
 {
 A =1,
 B =2,
 C =3,
 D =4
 }
}
