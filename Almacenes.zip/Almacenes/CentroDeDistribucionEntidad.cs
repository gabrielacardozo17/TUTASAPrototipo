namespace TUTASAPrototipo.Almacenes
{
    public class CentroDeDistribucionEntidad
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Direccion { get; set; } = string.Empty;
        public LocalidadEntidad Localidad { get; set; }
    }
}
