namespace TUTASAPrototipo.Almacenes
{
    public class EmpresaTransporteEntidad
    {
        public string CUIT { get; set; }
        public string Nombre { get; set; }
        public CuentaCorrienteEmpresaTransporte CuentaCorriente { get; set; }
    }
}
