namespace TUTASAPrototipo.Almacenes
{
    public enum ProvinciaEnumeracion
    {
        BuenosAires,
        Catamarca,
        Chaco,
        Chubut,
        CABA,
        Cordoba,
        Corrientes,
        EntreRios,
        Formosa,
        Jujuy,
        LaPampa,
        LaRioja,
        Mendoza,
        Misiones,
        Neuquen,
        RioNegro,
        SantaFe,
        Tucuman,
        TierraDelFuego,
    }
}
