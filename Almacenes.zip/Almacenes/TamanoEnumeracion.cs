namespace TUTASAPrototipo.Almacenes
{
    public enum TamanoEnumeracion
    {
        S,
        M,
        L,
        XL
    }
}
