namespace TUTASAPrototipo.Almacenes
{
    public enum EntregaEnum
    {
	    CD,
	    Agencia,
	    Domicilio
    }
}
