namespace TUTASAPrototipo.Almacenes
{
    public class LocalidadEntidad
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public ProvinciaEnumeracion Provincia { get; set; }
    }
}
